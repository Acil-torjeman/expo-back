// src/user/user.service.ts (only forgot password related methods)
import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { User } from './entities/user.entity';

@Injectable()
export class UserService {
  // Other methods...

  /**
   * Find user by reset token
   */
  async findByResetToken(token: string): Promise<User> {
    const user = await this.userModel.findOne({ 
      passwordResetToken: token,
      passwordResetExpires: { $gt: new Date() },
      deleted: { $ne: true }
    }).exec();
    
    if (!user) {
      throw new NotFoundException('Invalid or expired password reset token');
    }
    
    return user;
  }
  
  // Other methods...
}