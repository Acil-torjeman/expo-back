// src/auth/auth.service.ts (only forgot password related methods)
import { 
    Injectable, 
    NotFoundException,
    Logger,
    BadRequestException
  } from '@nestjs/common';
  import { InjectModel } from '@nestjs/mongoose';
  import { Model } from 'mongoose';
  import * as crypto from 'crypto';
  import * as argon2 from 'argon2';
  import { User } from '../user/entities/user.entity';
  import { MailerService } from '@nestjs-modules/mailer';
  import { ConfigService } from '@nestjs/config';
  import { ForgotPasswordDto } from './dto/forgot-password.dto';
  import { ResetPasswordDto } from './dto/reset-password.dto';
  import { UserService } from '../user/user.service';
  
  @Injectable()
  export class AuthService {
    private readonly logger = new Logger(AuthService.name);
  
    @InjectModel(User.name) private userModel: Model<User>;
  
    constructor(
      private userService: UserService,
      private mailerService: MailerService,
      private configService: ConfigService,
    ) {}
  
    // Other methods...
    
    /**
     * Forgot password
     */
    async forgotPassword(forgotPasswordDto: ForgotPasswordDto): Promise<any> {
      try {
        // Normalize email
        const normalizedEmail = forgotPasswordDto.email.trim().toLowerCase();
        this.logger.log(`Processing forgot password request for: ${normalizedEmail}`);
        
        // Try to find user by email, but don't throw if not found (security)
        let user;
        try {
          user = await this.userService.getUserWithToken(normalizedEmail);
        } catch (error) {
          // Don't reveal that email doesn't exist for security reasons
          return {
            message: 'If your email is registered, you will receive a password reset link shortly.',
          };
        }
        
        // Generate reset token
        const resetToken = crypto.randomBytes(32).toString('hex');
        const resetTokenExpiry = new Date();
        resetTokenExpiry.setHours(resetTokenExpiry.getHours() + 1); // Token expires in 1 hour
        
        // Update user with reset token
        await this.userModel.findByIdAndUpdate(
          user._id,
          { 
            passwordResetToken: resetToken,
            passwordResetExpires: resetTokenExpiry
          }
        );
        
        this.logger.log(`Reset token generated for user: ${normalizedEmail}`);
        
        // Send reset email
        const emailSent = await this.sendPasswordResetEmail(normalizedEmail, resetToken);
        
        if (!emailSent) {
          this.logger.error(`Failed to send password reset email to: ${normalizedEmail}`);
          throw new InternalServerErrorException('Failed to send password reset email');
        }
        
        this.logger.log(`Password reset email sent to: ${normalizedEmail}`);
        
        return {
          message: 'If your email is registered, you will receive a password reset link shortly.',
        };
      } catch (error) {
        // Handle specific errors
        if (error instanceof InternalServerErrorException) {
          throw error;
        }
        
        this.logger.error(`Error during forgot password: ${error.message}`, error.stack);
        throw new InternalServerErrorException('An error occurred during the password reset process');
      }
    }
  
    /**
     * Reset password
     */
    async resetPassword(resetPasswordDto: ResetPasswordDto): Promise<any> {
      try {
        const { token, password, passwordConfirmation } = resetPasswordDto;
        
        this.logger.log(`Processing password reset with token: ${token.substring(0, 10)}...`);
        
        // Confirm passwords match
        if (password !== passwordConfirmation) {
          throw new BadRequestException('Passwords do not match');
        }
        
        // Find user with valid token
        let user;
        try {
          user = await this.userService.findByResetToken(token);
        } catch (error) {
          this.logger.warn(`Invalid or expired password reset token: ${token.substring(0, 10)}...`);
          throw new BadRequestException('Invalid or expired password reset link');
        }
        
        // Hash the password before update
        const hashedPassword = await argon2.hash(password, {
          type: argon2.argon2id,
          memoryCost: 65536,
          timeCost: 3,
          parallelism: 4
        });
        
        // Update user password and clear reset token
        await this.userModel.findByIdAndUpdate(
          user._id,
          {
            $set: {
              password: hashedPassword,
              status: user.status === UserStatus.PENDING ? UserStatus.ACTIVE : user.status,
              emailVerified: user.status === UserStatus.PENDING ? true : user.emailVerified
            },
            $unset: {
              passwordResetToken: 1,
              passwordResetExpires: 1
            }
          }
        );
        
        this.logger.log(`Password reset successful for user: ${user.email}`);
        
        // Send confirmation email
        await this.sendPasswordResetSuccessEmail(user.email);
        
        return {
          message: 'Your password has been reset successfully',
        };
      } catch (error) {
        // Handle specific errors
        if (error instanceof BadRequestException) {
          throw error;
        }
        
        this.logger.error(`Error during password reset: ${error.message}`, error.stack);
        throw new InternalServerErrorException('An error occurred during the password reset process');
      }
    }
    
    /**
     * Send password reset email
     */
    private async sendPasswordResetEmail(email: string, token: string): Promise<boolean> {
      const frontendUrl = this.configService.get('FRONTEND_URL', 'http://localhost:5174');
      const resetUrl = `${frontendUrl}/reset-password?token=${token}`;
      const currentYear = new Date().getFullYear();
  
      try {
        this.logger.log(`Sending password reset email to: ${email}`);
        
        await this.mailerService.sendMail({
          to: email,
          subject: 'Reset Your Password',
          template: 'forgot-password',
          context: {
            resetUrl,
            supportEmail: 'support@expoplatform.com',
            companyName: 'My Expo Platform',
            year: currentYear,
          },
        });
        
        this.logger.log(`Password reset email sent successfully to ${email}`);
        return true;
      } catch (error) {
        this.logger.error(`Failed to send password reset email to ${email}: ${error.message}`, error.stack);
        return false;
      }
    }
  
    /**
     * Send password reset success email
     */
    private async sendPasswordResetSuccessEmail(email: string): Promise<boolean> {
      const frontendUrl = this.configService.get('FRONTEND_URL', 'http://localhost:5174');
      const loginUrl = `${frontendUrl}/login`;
      const currentYear = new Date().getFullYear();
  
      try {
        this.logger.log(`Sending password reset success email to: ${email}`);
        
        await this.mailerService.sendMail({
          to: email,
          subject: 'Your Password Has Been Reset',
          template: 'reset-password-success',
          context: {
            loginUrl,
            supportEmail: 'support@expoplatform.com',
            companyName: 'My Expo Platform',
            year: currentYear,
          },
        });
        
        this.logger.log(`Password reset success email sent to ${email}`);
        return true;
      } catch (error) {
        this.logger.error(`Failed to send password reset success email to ${email}: ${error.message}`, error.stack);
        return false;
      }
    }
    
    // Other methods...
  }