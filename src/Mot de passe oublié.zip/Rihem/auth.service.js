// src/services/auth.service.js (only the forgot password related methods)
import axios from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL;

export const authService = {
  // Other methods...
  
  // Forgot password
  forgotPassword: async (data) => {
    try {
      const response = await axios.post(`${API_BASE_URL}/auth/forgot-password`, data);
      return response.data;
    } catch (error) {
      console.error("Error in forgot password:", error);
      
      // Return standardized error
      if (error.response && error.response.data && error.response.data.message) {
        throw new Error(error.response.data.message);
      }
      throw new Error('Failed to process forgot password request');
    }
  },
  
  // Reset password
  resetPassword: async (data) => {
    try {
      const response = await axios.post(`${API_BASE_URL}/auth/reset-password`, data);
      return response.data;
    } catch (error) {
      console.error("Error in reset password:", error);
      
      // Parse error message
      if (error.response && error.response.data && error.response.data.message) {
        throw new Error(error.response.data.message);
      }
      throw new Error('Failed to reset password');
    }
  },
  
  // Other methods...
};