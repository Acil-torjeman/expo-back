// src/user/entities/user.entity.ts (only password reset related fields)
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import * as argon2 from 'argon2';

@Schema({ timestamps: true })
export class User extends Document {
  // Other fields...
  
  @Prop()
  passwordResetToken?: string;

  @Prop()
  passwordResetExpires?: Date;
  
  // Other fields...
}

// Schema with pre-save hook for password hashing
export const UserSchema = SchemaFactory.createForClass(User).pre("save", async function() {
  // Ne hacher que si le mot de passe est modifié et n'est pas déjà haché
  if (this.isModified('password') && !this.password.startsWith('$argon2id$')) {
    this.password = await argon2.hash(this.password, {
      type: argon2.argon2id,
      memoryCost: 65536,
      timeCost: 3,
      parallelism: 4
    });
  }
});